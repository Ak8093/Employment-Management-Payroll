package com.task_manager.Tharun.repository;

import com.task_manager.Tharun.model.Task;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TaskRepository extends MongoRepository<Task, String> {
}