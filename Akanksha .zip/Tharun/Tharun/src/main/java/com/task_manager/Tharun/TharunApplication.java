package com.task_manager.Tharun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TharunApplication {
	public static void main(String[] args) {
		SpringApplication.run(TharunApplication.class, args);
	}
}